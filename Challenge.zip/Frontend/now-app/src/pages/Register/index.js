import React, { useState, useEffect } from "react";
import axios from 'axios';
import { useNavigate } from "react-router-dom"

import FormControlUnstyled, {
    useFormControlUnstyledContext,
} from '@mui/base/FormControlUnstyled';
import InputUnstyled, { inputUnstyledClasses } from '@mui/base/InputUnstyled';
import { styled } from '@mui/system';
import clsx from 'clsx';
import Button from '@mui/material/Button';
import Box from '@mui/material/Box';
import InputLabel from '@mui/material/InputLabel';
import MenuItem from '@mui/material/MenuItem';
import FormControl from '@mui/material/FormControl';
import Select, { SelectChangeEvent } from '@mui/material/Select';

import Swal from 'sweetalert2'


const blue = {
    100: '#DAECFF',
    200: '#80BFFF',
    400: '#3399FF',
    600: '#0072E5',
};

const grey = {
    50: '#F3F6F9',
    100: '#E7EBF0',
    200: '#E0E3E7',
    300: '#CDD2D7',
    400: '#B2BAC2',
    500: '#A0AAB4',
    600: '#6F7E8C',
    700: '#3E5060',
    800: '#2D3843',
    900: '#1A2027',
};

const Input = styled(InputUnstyled)(
    ({ theme }) => `
  
  .${inputUnstyledClasses.input} {
    width: 320px;
    font-size: 0.875rem;
    font-family: IBM Plex Sans, sans-serif;
    font-weight: 400;
    line-height: 1.5;
    color: ${theme.palette.mode === 'dark' ? grey[300] : grey[900]};
    background: ${theme.palette.mode === 'dark' ? grey[900] : grey[50]};
    border: 1px solid ${theme.palette.mode === 'dark' ? grey[800] : grey[300]};
    border-radius: 8px;
    padding: 12px 12px;

    &:hover {
      background: ${theme.palette.mode === 'dark' ? '' : grey[100]};
      border-color: ${theme.palette.mode === 'dark' ? grey[700] : grey[400]};
    }

    &:focus {
      outline: 3px solid ${theme.palette.mode === 'dark' ? blue[600] : blue[100]};
    }
  }
`,
);

const Label = styled(
    ({ children, className }: { children?: React.ReactNode; className?: string }) => {
        const formControlContext = useFormControlUnstyledContext();
        const [dirty, setDirty] = React.useState(false);

        React.useEffect(() => {
            if (formControlContext?.filled) {
                setDirty(true);
            }
        }, [formControlContext]);

        if (formControlContext === undefined) {
            return <p>{children}</p>;
        }

        const { error, required, filled } = formControlContext;
        const showRequiredError = dirty && required && !filled;

        return (
            <p className={clsx(className, error || showRequiredError ? 'invalid' : '')}>
                {children}
                {required ? ' *' : ''}
            </p>
        );
    },
)`
  font-family: IBM Plex Sans, sans-serif;
  font-size: 0.875rem;
  margin-bottom: 4px;

  &.invalid {
    color: red;
  }
`;

const HelperText = styled((props: {}) => {
    const formControlContext = useFormControlUnstyledContext();
    const [dirty, setDirty] = React.useState(false);

    React.useEffect(() => {
        if (formControlContext?.filled) {
            setDirty(true);
        }
    }, [formControlContext]);

    if (formControlContext === undefined) {
        return null;
    }

    const { required, filled } = formControlContext;
    const showRequiredError = dirty && required && !filled;

    return showRequiredError ? <p {...props}>This field is required.</p> : null;
})`
  font-family: IBM Plex Sans, sans-serif;
  font-size: 0.875rem;
`;

function Register() {
    const [permissionType, setPermissionType] = useState([]);
    const [form, setForm] = useState({
        nombreEmpleado: '',
        apellidoEmpleado: '',
        tipoPermiso: '',
        fechaPermiso: ''
    });
    let navigate = useNavigate();

    const url = 'https://localhost:7037';
    const ListForm = [
        {
            name: 'nombreEmpleado',
            text: 'Name',
            type: 'text'
        },
        {
            name: 'apellidoEmpleado',
            text: 'Last Name',
            type: 'text'
        },
        {
            name: 'tipoPermiso',
            text: 'Permission Type',
            type: 'select'
        },
        {
            name: 'fechaPermiso',
            text: 'Permission Date',
            type: 'date'
        },
    ];

    const HandleCreate = async () => {
        try {


            try {
                if (form.nombreEmpleado === '') {
                    Swal.fire(
                        'Good job!',
                        'Name is required!',
                        'error'
                    )
                }
                else if (form.apellidoEmpleado === '') {
                    Swal.fire(
                        'Good job!',
                        'Last Name is required!',
                        'error'
                    )
                }
                else if (form.tipoPermiso === '') {
                    Swal.fire(
                        'Good job!',
                        'Permission type is required!',
                        'error'
                    )
                }
                else if (form.fechaPermiso === '') {
                    Swal.fire(
                        'Good job!',
                        'Permission date is required!',
                        'error'
                    )
                }
                else {
                    axios.post(`${url}/api/permission`, form)
                        .then(function (response) {
                            console.log(response);
                            Swal.fire(
                                'Good job!',
                                'Successful registration!',
                                'success'
                            )
                        })
                        .catch(function (error) {
                            Swal.fire(
                                'Error!',
                                error,
                                'error'
                            )
                            console.log(error);
                        });
                }
            } catch (e) {
                console.log("Error", e);
            }
        } catch (error) {
            console.log("error", error);
        }
    }
    const HandleReturn = async () => {
        navigate("/");
    }

    const HandleData = async () => {
        try {
            let response = await axios({
                url: `${url}/api/permissiontype`,
                method: 'GET',
            })
            setPermissionType(response.data);
        } catch (e) {
            console.log("Error", e);
        }
    }

    useEffect(() => {
        try {
            HandleData();
        } catch (error) {
            console.log("error", error);
        }

    }, []);
    return (
        <div style={{ padding: "0px 0px 0px 10px" }}>
            {ListForm.map((item, index) =>
                <div key={index}>
                    {item.type === 'select' ? (
                        <FormControl style={{ minWidth: 347 }}>
                            <Label>{item.text}</Label>
                            {/* <InputLabel id="demo-simple-select-label">{item.text}</InputLabel> */}
                            <Select
                                labelId="demo-simple-select-label"
                                id="demo-simple-select"
                                label={item.text}
                                onChange={(e) => setForm({
                                    ...form,
                                    [item.name]: e.target.value
                                })}
                            >
                                {permissionType.map((item2, index) => {
                                    return <MenuItem key={index} value={item2.id}>{item2.descripcion}</MenuItem>
                                })}
                            </Select>
                        </FormControl>
                    ) :
                        (
                            <FormControlUnstyled defaultValue="" required>
                                <Label>{item.text}</Label>
                                <Input
                                    type={item.type}
                                    onChange={(e) => setForm({
                                        ...form,
                                        [item.name]: e.target.value
                                    })}
                                />
                                <HelperText />
                            </FormControlUnstyled>
                        )}

                </div>
            )}
            <br />
            <Button variant="contained" onClick={() => HandleCreate()}>Create</Button>
            {" "}
            <Button variant="contained" onClick={() => HandleReturn()}>Return</Button>
        </div>

    );
}

export default Register;
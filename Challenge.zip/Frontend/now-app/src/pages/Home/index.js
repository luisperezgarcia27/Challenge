import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom"
import Swal from 'sweetalert2'
import axios from 'axios';

import { DataGrid, GridColDef, GridValueGetterParams } from '@mui/x-data-grid';
import Button from '@mui/material/Button';
import Select, { SelectChangeEvent } from '@mui/material/Select';

function Home() {
    const [permission, setPermission] = useState([]);
    const [permissionType, setPermissionType] = useState([]);
    const [editRowsModel, setEditRowsModel] = useState({});
    const [editRowData, setEditRowData] = useState({});
    const [editId, setEditId] = useState(0);
    const [selectValue, setSelectValue] = useState(0);
    let navigate = useNavigate();
    const url = 'https://localhost:7037';
    const renderSelectEditInputCell = () => {
        return (
            <Select
                size="small"
                sx={{ height: 1, width: '100%' }}
                native
                autoFocus
                value={selectValue}
                onChange={(e) => setSelectValue(e.target.value)}
            >
                {permissionType.map((item, index) => {
                    return <option key={index} value={item.id}>{item.descripcion}</option>
                })}
            </Select>
        )
    }
    const columns: GridColDef[] = [
        { field: 'id', headerName: 'ID' },
        { field: 'nombreEmpleado', headerName: 'First name', width: 200, editable: true },
        { field: 'apellidoEmpleado', headerName: 'Last name', width: 200, editable: true },
        { field: 'tipoPermisoNavigation', headerName: 'Permit Type', width: 200, editable: true, renderEditCell: renderSelectEditInputCell, },
        { field: 'fechaPermiso', headerName: 'Permit Date', width: 200, editable: true, type: 'date' },
    ];
    const HandleData = async () => {

        let data = [];

        try {
            let response = await axios({
                url: `${url}/api/permission`,
                method: 'GET',
            })
            if (response.data.length > 0) {
                response.data.forEach(element => {
                    data.push({
                        'id': element.id,
                        'nombreEmpleado': element.nombreEmpleado,
                        'apellidoEmpleado': element.apellidoEmpleado,
                        'tipoPermisoNavigation': element.tipoPermisoNavigation,
                        'tipoPermiso': element.tipoPermiso,
                        'fechaPermiso': element.fechaPermiso.slice(0, 10),
                    })
                })
                setPermission(data);

            }
        } catch (e) {
            console.log("Error", e);
        }
    }
    const HandleTypePermission = async () => {
        try {
            let response = await axios({
                url: `${url}/api/permissiontype`,
                method: 'GET',
            })
            setPermissionType(response.data);
        } catch (e) {
            console.log("Error", e);
        }
    }
    const HandleCreate = () => {
        navigate("/register")
    }
    const HandleUpdate = async (id, form) => {
        try {
            axios.put(`${url}/api/permission/${id}`, form)
                .then(function () {
                    Swal.fire(
                        'Good job!',
                        'Successful update!',
                        'success'
                    )
                })
                .catch(function (error) {
                    Swal.fire(
                        'Error!',
                        error,
                        'error'
                    )
                });
        } catch (e) {
            console.log("Error", e);
        }
    }
    const HandleEditRowsModelChange = async (model) => {
        const editedIds = Object.keys(model);
        if (editedIds.length === 0) {

            const form = JSON.stringify(editRowData, null, 4);
            let typePermission = '';
            permissionType.forEach(element => {
                if (element.id == selectValue) {
                    typePermission = element.descripcion;
                }
            });
            let newPermission = [];



            permission.forEach(element => {
                if (editId == element.id) {
                    element.tipoPermiso = selectValue;
                    element.tipoPermisoNavigation = typePermission;
                    console.log("element", element);
                }
                newPermission.push(element);
            });
            setPermission(newPermission);
            let formJsonParce = {
                nombreEmpleado: JSON.parse(form).nombreEmpleado.value,
                apellidoEmpleado: JSON.parse(form).apellidoEmpleado.value,
                tipoPermiso: selectValue,
                tipoPermisoNavigation: typePermission,
                fechaPermiso: JSON.parse(form).fechaPermiso.value,
            }
            await HandleUpdate(editId, formJsonParce);
        } else {
            if (model[editedIds[0]].nombreEmpleado.value == '') {
                Swal.fire(
                    'Error!',
                    'Name is Required',
                    'error'
                );
                permission.forEach(element => {
                    if (element.id == editId) {
                        model[editedIds[0]].nombreEmpleado.value = element.nombreEmpleado;
                    }
                });
            }
            else if (model[editedIds[0]].apellidoEmpleado.value == '') {
                Swal.fire(
                    'Error!',
                    'Last name is Required',
                    'error'
                );
                permission.forEach(element => {
                    if (element.id == editId) {
                        model[editedIds[0]].apellidoEmpleado.value = element.apellidoEmpleado;
                    }
                });
            }
            else {
                setEditId(editedIds[0]);
                setEditRowData(model[editedIds[0]]);
            }
        }
    }
    useEffect(() => {
        try {
            HandleData();
            HandleTypePermission();
        } catch (error) {
            console.log("error", error);
        }

    }, []);
    useEffect(() => {
        if (editId !== 0) {
            permission.forEach(element => {
                if (element.id == editId) {
                    setSelectValue(element.tipoPermiso);
                }
            });
        }
    }, [editId]);
    return (
        <div style={{ padding: "0px 0px 0px 10px" }}>
            <br />
            <Button variant="contained" onClick={() => HandleCreate()}>Create</Button>
            <div style={{ height: '90vh', width: '100%' }}>
                <DataGrid
                    rows={permission}
                    columns={columns}
                    editMode="row"
                    onEditRowsModelChange={HandleEditRowsModelChange}
                />
            </div>
        </div>

    );
}

export default Home;